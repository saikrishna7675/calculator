console.log(__dirname);
